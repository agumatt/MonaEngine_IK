This is the build directory of ViennaCL. Build here using
$> cmake ..
$> make
A wider range of options is available with 
$> ccmake ..
or
#> cmake-gui ..

If you wish to use Boost, but CMake cannot find it, customize BOOSTPATH variable in ../CMakeLists.txt.

